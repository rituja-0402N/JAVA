public class Object {
    public static void main(String[] args) {
        Laptop l1 = new Laptop();
        l1.model = "Dell";
        l1.price = 100;

        Laptop l2 = new Laptop();
        l1.model = "Lenovo";
        l1.price = 200;
    }

}

class Laptop {
    String model;
    int price;

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    // public String toString() {
    // return("model + " " + price");
    // }
}