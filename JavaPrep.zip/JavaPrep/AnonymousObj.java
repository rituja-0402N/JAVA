// public class AnonymousObj {
// public static void main(String[] args) {

// Demo D = new Demo();
// // new Demo().show(); ---obj creation
// // D.show();
// }
// }

// class Demo {
// public Demo() {
// System.out.println("object created");
// }

// public void show() {
// System.out.println("in A show");
// }
// }