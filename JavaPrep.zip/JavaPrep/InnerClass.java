
public class InnerClass {

    public static void main(String[] args) {
        A obj = new A() {// Anonymous inner class
            public void show() {
                System.out.println("in new show");
            }
        };
        obj.show();

        A.B obj1 = obj.new B(); // calling inner class
        obj1.config();

    }
}

class A {

    public void show() {
        System.out.println("in show");
    }

    class B {
        public void config() {
            System.out.println("in config");
        }
    }
}
