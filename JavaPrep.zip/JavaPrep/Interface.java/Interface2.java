package Interface.java;

public class Interface2 {
    public static void main(String[] args) {
        A obj;
        X obj2 = new V();
        obj = new V();
        obj.show();
        obj2.dance();

    }

}

interface A {
    int age = 99; // final & static

    void show();

}

interface X {

    void dance();
}

class V implements A, X {
    public void show() {
        System.out.println("hiujk");
    }

    public void dance() {
        System.out.println("dancing tonight");

    }
}