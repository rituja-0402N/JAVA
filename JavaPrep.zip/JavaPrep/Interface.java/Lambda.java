package Interface.java;

public class Lambda {
    public static void main(String[] args) {
        A obj = ( i,  j) => i + j; 
    }
}

@FunctionalInterface
/**
 * InnerLambda
 */
public interface InnerLambda {
    int add(int i, int j);

}