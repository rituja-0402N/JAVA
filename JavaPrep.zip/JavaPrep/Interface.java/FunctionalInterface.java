package Interface.java;

public class FunctionalInterface {
    public static void main(String[] args) {
        A obj = () -> System.out.println("in A");
        obj.show();
    }
}

// @FunctionalInterface
interface A {

    void show();

    // void run();
}
