package Interface.java;

public class Interface1 {
    public static void main(String[] args) {
        Laptop lap = new Laptop();
        Desktop des = new Desktop();
        des.code();

        Developer rituja = new Developer();
        rituja.Dev(lap);
    }
}

class Developer {
    public void Dev(Computer lap) {
        lap.code();
        System.out.println("in dev");
    }
}

class Laptop implements Computer {
    public void code() {
        System.out.println("get Laptop");
    }
}

interface Computer {
    public abstract void code();
}

class Desktop implements Computer {
    public void code() {
        System.out.println("get Desktop");
    }
}