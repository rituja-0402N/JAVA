public class StaticDemo {
    public static void main(String[] args) {

        Mobile mobile = new Mobile();
        mobile.brand = "Apple";
        mobile.price = 1500;
        mobile.name = "SmartPhone";

        Mobile mobile2 = new Mobile();
        mobile2.brand = "Samsung";
        mobile2.price = 1800;
        mobile2.name = "SmartPhone";
        Mobile.name = "Myphone";
        mobile.show();
        mobile2.show();
        Mobile.nameshow1(mobile2);
        // Static variables can be called by class name and shared by that class name.
        // Static method can be called by class instead of objects. they can not have
        // non static variable.
        // Mobile.name = "Myphone";

    }
}

/**
 * InnerStaticDemo
 */
public class Mobile {

    String brand;
    int price;
    static String name;

    static {
        name = "PPhone";
        System.out.println("in static block");
    }

    public Mobile() {
        brand = "";
        price = 200;
        System.out.println("in constructor");
    }

    public void show() {

        System.out.println("The item: " + brand + " has price " + price + " and name " + name);
    }

    // Static method
    public static void nameshow1(Mobile obj) {
        System.out.println("In static method");
        System.out.println("The item: " + obj.brand + " has price " + obj.price + " and name " + obj.name);

    }

}