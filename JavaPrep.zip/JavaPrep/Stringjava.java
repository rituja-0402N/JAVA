public class Stringjava {
    public static void main(String[] args) {
        String name = new String("rituja");
        System.out.println("Hello\t" + name);
        // System.out.println(name.charAt(4));
        System.out.println(name.concat(" Narvekar"));

        // StringBuffer --thread safe
        StringBuffer sb = new StringBuffer("nar");
        System.out.println(sb.capacity());
        sb.append("ritzz");

        sb.insert(3, "vekar");
        System.out.println(sb.toString());
    }

}