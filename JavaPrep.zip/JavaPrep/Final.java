//final - variable,method,class
//final variable is immutable
//final class stops inheritance
//final method stops method overriding
public class Final {
    public static void main(String[] args) {
        final int num = 9;
        // num = 10;
        System.out.println(num);
    }

}

final class A {
    public void show(int a, int b) {
        System.out.println(a + b);
    }
}

class B { // can not extend class A
    public void show(int a, int b) {
        System.out.println(a + b);
    }
}