
public class Javafile {
    public static void main(String[] args) {
        int num = 3;
        System.out.println("Hello Java\n" + num);

        float marks = 66.90f;
        double totalmarks = 700.100d;
        double result = (int) (marks / totalmarks * 100);
        result += 10;
        System.out.println(result);

        char c = 'k';
        System.out.println(c);

    }

}
