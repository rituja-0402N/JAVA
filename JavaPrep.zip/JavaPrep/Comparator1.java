import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
//import java.util.Comparator;

public class Comparator1 {
    public static void main(String[] args) {
        Comparator<Integer> com = new Comparator<Integer>() {

            public int compare(Integer i, Integer j) {
                if (i % 10 > j % 10)
                    return 1;
                else
                    return -1;
            }
        };

        List<Integer> int1 = new ArrayList<Integer>();
        int1.add(43);
        int1.add(45);
        int1.add(24);

        Collections.sort(int1, com);
    }
}