
import java.util.Arrays;
import java.lang.Math;

public class Javaarray {

    public static void main(String[] args) {

        int nums[] = { 4, 7, 8, 9 };
        int dynamicNums[] = new int[2];
        dynamicNums[0] = 9;
        dynamicNums[1] = 5;
        for (int i = 0; i < nums.length; i++) {
            System.out.println(nums[i]);
        }
        System.out.println(Arrays.toString(dynamicNums));
        // Random values
        // int random = (int) Math.Random() * 100;
        // System.out.println(random);

        for (int n : nums) {
            if (n == 7) {
                System.out.println(n);
            }
        }

        // multi-dimensional array
        int nums2[][] = new int[4][3];
        for (int col = 0; col < 4; col++) {

            for (int row = 0; row < 3; row++) {

                nums2[col][row] = (int) (Math.random() * 100);
                // System.out.println(nums2[col][row]);
            }
        }

        for (int col = 0; col < 4; col++) {

            for (int row = 0; row < 3; row++) {

                // nums2[col][row] = (int) Math.Random() * 100;
                System.out.println(nums2[col][row]);
            }
        }

        // JAGGED ARRAY
        // int nums3[] = new int[3][];

        // nums3[0] = new int[2];
        // nums3[1] = new int[3];
        // nums3[2] = new int[4];
        // for (int col = 0; col < nums3.length; col++) {

        // for (int row = 0; row < nums3.length; row++) {

        // nums2[col][row] = (int) (Math.random() * 100);
        // // System.out.println(nums2[col][row]);
        // }
        // }
    }
}