public class Encapsulation {
    public static void main(String[] args) {
        Demo demo = new Demo();
        demo.setAge(30);
        demo.setSuite(156);
        System.out.println(demo.getAge() + " and suite " + demo.getSuite());
    }
}

class Demo {
    private int age = 21;
    private int suite = 157;

    public int getAge() {
        return age;
    }

    public int getSuite() {
        return suite;
    }

    public void setAge(int a) {
        age = a;
    }

    public void setSuite(int a) {
        suite = a;
    }

}