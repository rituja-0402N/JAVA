import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;

import java.util.Iterator;

public class CollectionAPI {
    public static void main(String[] args) {

        Collection<Integer> num = new ArrayList<Integer>();
        num.add(7);
        num.add(8);
        num.add(9);
        num.add(5);
        for (Object n : num) {
            System.out.println(num);
        }
        // System.out.println(num.indexOf(2));

        List<Integer> nums2 = new ArrayList<Integer>();
        nums2.add(7);
        nums2.add(4);
        nums2.add(7);
        nums2.add(8);

        for (Object o : nums2) {
            int num1 = (Integer) o;
            // System.out.println(num1 * 2);

        }
        // Set
        Set<Integer> numbers = new HashSet<Integer>();
        numbers.add(6);
        numbers.add(6);
        numbers.add(7);

        Iterator<Integer> val = numbers.iterator();
        while (val.hasNext()) {
            System.out.println(val.next());
        }

        // Map
        Map<Integer, String> map1 = new HashMap<Integer, String>();
        map1.put(01, "Wagon St");
        map1.put(02, "Lexington Ave");
        map1.put(03, "59th Columbus Circle");

        System.out.println(map1.get(02));
        for (Integer k : map1.keySet()) {
            System.out.println(k + " : " + map1.get(k));
        }
        System.out.println(map1.keySet());
        System.out.println(map1.values());

    }

}
