public class Inheritence {
    public static void main(String[] args) {
        VeryAdvanceCalc vObj = new VeryAdvanceCalc();
        int v1 = vObj.sub(7, 2);
        int v2 = vObj.add(7, 5);
        // System.out.println(vObj.power(5, 5) + v1 + v2);
        // vObj.power(5, 5);

        // Dynamic Runtime Polymorphism
        AdvCalc ad = new VeryAdvanceCalc();
        System.out.println(ad.add(5, 6));
        // ad.add(5, 6);

        ad = new VeryAdvanceCalc();
        System.out.println(ad.add(57, 6));

    }
}

public class Calc {
    public int add(int n1, int n2) {
        System.out.println("in Calc");
        return n1 + n2;
    }
}

public class AdvCalc extends Calc {
    public int sub(int n1, int n2) {
        return n2 - n1;
    }

    public int add(int n1, int n2) {
        System.out.println("in AdvCalc");
        return n1 + n2;
    }

}

public class VeryAdvanceCalc extends AdvCalc {
    public double power(int n1, int n2) {
        return Math.pow(n1, n2);

    }

    public int add(int n1, int n2) {
        System.out.println("in VeryAdvCalc");
        return n1 + n2;
    }
}